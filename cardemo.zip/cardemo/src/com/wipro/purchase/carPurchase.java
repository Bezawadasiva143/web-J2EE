package com.wipro.purchase;

import com.wipro.model.Car;
import com.wipro.model.Engine;




/*
 * here ,the application,carpurchase is explicitly instantiating ,initializing,injecting and destroying the 
 * dependencies
 * 
 * the strong bonding between the application and the dependencies with is not 
 * suggestible,instead recommended concept      is loosse-coupling
 * 
 * how to achieve loose coupling?
 * Instead of application or dependent object managing the life-cycle of dependencies,
* hand over this responsibility to some third-party so that the third-party will manage
* the dependencies.
*
* This third-party can be Spring or Struts or JSF and so on.
*
* Spring container manages the dependencies. Earlier it was dependent taking care of all these, now
* the control of managing the dependencies to handed over to a third-party ie. control has been
* inverted hence the term inversion-control.
*

 */

public class carPurchase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//dependency
		Engine engine = new Engine(12345678L,2700.0,"petrol");
		
		//constructor injection
		
		Car mycar= new Car("Maruthi ","grand vitara",engine);
		System.out.println(mycar);
		
		
		Car myanothercar = new Car();
		
		// setter injection
		myanothercar.setEngine(engine);
		myanothercar.setBrand("hyndai");
		myanothercar.setModel("verna");
		
		
	}

}
