package com.wipro.config;

public class ThymeleafConfig {

}
