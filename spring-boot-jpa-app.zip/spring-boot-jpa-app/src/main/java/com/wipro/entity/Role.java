package com.wipro.entity;

public enum Role {
	
	ADMIN,DOCTOR,GROUP


}
