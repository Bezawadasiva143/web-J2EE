package com.wipro.controller;

import java.awt.PageAttributes.MediaType;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.model.User;

@RestController
@RequestMapping("/uc")

public class UseContoller {
	//http://localost:8081/spring-mvc-app/uc/hello
	
	@RequestMapping("/hello")
	public String sayHello() {
		return "hello,how are you?";
	}
	
	//http://localhost:8081/spring-mvc-app/uc/users?username=siva&password=siva@123
	@GetMapping("/users")
	public String checkCredentials(@RequestParam(value = "username") String username,
									@RequestParam(value = "password") String password) {
		
		User user = new User("siva","siva@123");
		
		if(username.equals(user.getUserName()) && password.equals(user.getPassword())) {
			return "Valid Credentials";
		}else {
			return "Invalid Credentials";
		}
	}
	//http://localhost:8081/spring-mvc-app/uc/users/siva/siva@123
		@GetMapping("/users/{username}/{password}")
		public String verifyCredentials( @PathVariable(value = "username") String username,
										 @PathVariable(value = "password") String password) {
			User user = new User("siva","siva@123");
			
			if(username.equals(user.getUserName()) && password.equals(user.getPassword())) {
				return "Valid Credentials";
			}else {
				return "Invalid Credentials";
			}
			
		}


/* Following method receives User object from client application.
	 * The client application ex. postman has to send the User object JSON object.
	 *
	 * @RequestBody will receive JSON object and convert it to User object implicitly.
	 *
	 */
	
	@PostMapping(value = "/users", consumes = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public User addUser(@RequestBody User user) {
		System.out.println(user.getUserName()+" saved");
		return user;


		
}



			
	}



 

